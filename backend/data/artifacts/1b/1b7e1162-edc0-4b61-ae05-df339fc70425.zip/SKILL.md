---
name: uart-read
description: Read data from a UART serial port on embedded devices
tags: ["embedded", "uart", "serial", "read"]
---

## Instructions

1. Open the specified serial port with given baud rate
2. Set read timeout to avoid blocking
3. Read bytes until newline or timeout
4. Decode bytes to string
5. Return the received data

## Parameters
- port: serial port path (e.g. /dev/ttyUSB0 or COM3)
- baud_rate: baud rate (default 115200)
- timeout: read timeout in seconds (default 1.0)

