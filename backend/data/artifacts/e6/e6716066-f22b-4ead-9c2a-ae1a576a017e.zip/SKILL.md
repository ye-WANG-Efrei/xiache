---
name: web-fetch
description: Fetch and parse the text content of any webpage given a URL
tags: [web, scraping, read]
---

# Web Fetch Skill

## Instructions

1. Accept a URL as input
2. Send an HTTP GET request to the URL
3. Parse the HTML response and extract clean text content
4. Return the title, main text, and all links found on the page

## Example

Input: `https://example.com`
Output:
- title: "Example Domain"
- content: "This domain is for use in illustrative examples..."
- links: ["https://www.iana.org/domains/example"]
